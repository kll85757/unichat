const isProd = true;
const projectId = 'd9651bd9051b7fbcdf6c6963c3c5e129';
const xmtpHost = isProd ? 'production.xmtp.network' : 'dev.xmtp.network';
