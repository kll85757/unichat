import 'package:fluro/fluro.dart';
class Application {
  // static FluroRouter routes = FluroRouter();
  static late FluroRouter routes = FluroRouter();
}
