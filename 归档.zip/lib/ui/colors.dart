import 'dart:ui';

class EthColors {
  static const violetBlue = Color.fromARGB(255, 0, 159, 211);
  static const lavender = Color.fromARGB(255, 255, 255, 255);
  static const mimiPink = Color.fromARGB(255, 255, 255, 255);
  static const cherryPink = Color.fromARGB(255, 165, 233, 244);
  static const chinaRose = Color.fromARGB(255, 241, 241, 241);
  static const bgColor = Color.fromARGB(255, 241, 241, 241);
}

   Color infoBg = Color.fromARGB(255, 239, 239, 243);

TextStyle defultBtnText =
    TextStyle(fontSize: 18, color: Color.fromARGB(255, 255, 255, 255));
// TextStyle defultText =
//     TextStyle(fontSize: 18, color: Color.fromARGB(255, 70, 70, 70));
