import 'dart:typed_data';

import 'package:auto_route/auto_route.dart';
import 'package:dfunc/dfunc.dart';
import 'package:fast_immutable_collections/fast_immutable_collections.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:protobuf/protobuf.dart';
import 'package:provider/provider.dart';

import '../../session/data/session.dart';
import '../data/models/message.dart';
import '../services/chat_service.dart';
import 'widgets/chat_input_widget.dart';
import 'widgets/message_widget.dart';

import 'package:intl/intl.dart';
import 'package:xmtp/xmtp.dart' as xmtp;

import '../../../../utils/namespace.dart';
import '../../wallet_connect/presentation/wallet_connect_screen.dart';
import '../data/models/message.dart';

@RoutePage()
class MessageScreen extends StatefulWidget {
  const MessageScreen({
    super.key,
    required this.topic,
  });

  final String topic;

  @override
  State<MessageScreen> createState() => _State();
}

class _State extends State<MessageScreen> {
  late final ChatService _service;
  late final Session _session;

  // xmtp.EncodedContent Function(List<int> i, [ExtensionRegistry r]) _decode(msg) {
  //   final text = xmtp.EncodedContent.fromBuffer;
  //   return text;
  // }

  //   Future<xmtp.EncodedContent> encode(int decoded) async => xmtp.EncodedContent(
  //   type: contentType,
  //   content: Uint8List(8)..buffer.asByteData().setInt64(0, decoded),
  //   fallback: decoded.toString(),
  // );

  @override
  void initState() {
    super.initState();
    _service = context.read<ChatService>();
    _session = context.read<Session>();
  }

  @override
  Widget build(BuildContext context) => CupertinoPageScaffold(
        navigationBar: CupertinoNavigationBar(
          middle: Text(''),
          // title: Text(widget.topic),
        ),
        child: Container(
          // onRefresh: () => _service.refreshMessages(widget.topic),
          child: SafeArea(
            child: Material(
              child: ChatInputWidget(
                onNewMessage: (message) => _service.sendMessage(
                  topic: widget.topic,
                  message: message,
                ),
                child: StreamBuilder(
                  stream: _service.watchMessages(widget.topic),
                  builder: (context, snapshot) {
                    final messages = snapshot.data
                        .ifNull(() => const IListConst<Message>([]));

                    //  Object txt = _decode(messages[0]);
                    //  print(txt);
                    print('txttxttxttxttxttxttxttxttxttxt');
                    return ListView.builder(
                      reverse: true,
                      itemCount: messages.length,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      itemBuilder: (context, index) {
                        final message = messages.elementAt(index);
                        Future<Object> _decode() => message.encoded
                            .let(xmtp.EncodedContent.fromBuffer)
                            .let(codecs.decode)
                            .letAsync((it) => it.content);

                        Future<int> decode(xmtp.EncodedContent encoded) async =>
                            Uint8List.fromList(context as List<int>)
                                .buffer
                                .asByteData()
                                .getInt64(0);
                        // return Text(_decode(message) as String);
                        return FutureBuilder(
                          future: _decode(),
                          builder: (context, snapshot) {
                            final content = snapshot.data;
                            print(content);
                            if (content is String) {
                              return Text(content);
                            } // TODO(rhbrunetto): add support to other content types
                            return const SizedBox.shrink();
                          },
                        );
                        ;
                        // return Text(message.toString());
                        // return MessageWidget(
                        //   message: message,
                        //   isMine: message.sender == _session.address,
                        // );
                      },
                    );
                  },
                ),
              ),
            ),
          ),
        ),
      );
}
